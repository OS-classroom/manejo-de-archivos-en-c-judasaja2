#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct infoProceso infoProceso;
infoProceso leerInformacionProceso(char ruta[]);
void printInfo(infoProceso);
void guardarInfo(char archivo[], char proceso[], infoProceso info);
void mostrarValidos();

struct infoProceso {
  char nombre[20];
  char estado[20];
  char tam_total[20];
  char tam_text[20];
  char tam_data[20];
  char tam_stack[20];
  char cambio_contexto_v[20];
  char cambio_contexto_nv[20];
};

int main(int argc, char **argv){
  infoProceso proc;
  char ruta[80];
  char archivo[80];
  int i = 2;

  if(strcmp(argv[1], "-l") == 0 && argc > 3){
    printf("-- Información recolectada -- \n");
    while(argv[i] != NULL){
      strcpy(ruta, "/proc/");//"");
      strcat(ruta, argv[i]);
      strcat(ruta, "/status");//
      proc = leerInformacionProceso(ruta);
      printf(" Pid: %s \n", argv[i]);
      printInfo(proc);
      printf("\n");
      i++;
    }
  } else if(strcmp(argv[1], "-r") == 0 && argc > 3){
    FILE *fp;
    strcpy(archivo, "psinfo-report");
    while(argv[i] != NULL){
        strcat(archivo, "-");
        strcat(archivo, argv[i]);
        i++;
    }
    strcat(archivo, ".info");
    fp = fopen(archivo, "w");
    if(fp == NULL){
        printf("No se pudo crear el archivo \n");
        exit(1);
    } else {
        printf("Archivo de salida generado: %s \n", archivo);
    }
    fprintf(fp, "-- Información recolectada -- \n");
    fclose(fp);
    i = 2;
    while(argv[i] != NULL){
      strcpy(ruta, "/proc/");//"");
      strcat(ruta, argv[i]);
      strcat(ruta, "/status");//
      proc = leerInformacionProceso(ruta);
      guardarInfo(archivo, argv[i], proc);
      i++;
    }
  } else if(argc == 2){
      strcpy(ruta, "/proc/");//"");
      strcat(ruta, argv[1]);
      strcat(ruta, "/status");//
      proc = leerInformacionProceso(ruta);
      printInfo(proc);
  } else{
      mostrarValidos();
  }
}

infoProceso leerInformacionProceso(char ruta[]){
  infoProceso info;
  char linea_nombre[25];
  char linea_contenido[50];
  
  FILE *fp;
  fp = fopen(ruta,"r");
  if(fp == NULL) {
    printf("No se encontró o no se pudo abrir el archivo %s\n", ruta);
    exit(1);
  }

  while(fscanf(fp, "%s%*c%[^\n]", linea_nombre, linea_contenido)!=EOF){
    if(strcmp(linea_nombre, "Name:") == 0){
        strcpy(info.nombre, linea_contenido);
    }else if(strcmp(linea_nombre, "State:") == 0){
        strcpy(info.estado, linea_contenido);
    }else if(strcmp(linea_nombre, "VmSize:") == 0){
        strcpy(info.tam_total, linea_contenido);
    }else if(strcmp(linea_nombre, "VmExe:") == 0){
        strcpy(info.tam_text, linea_contenido);
    }else if(strcmp(linea_nombre, "VmData:") == 0){
        strcpy(info.tam_data, linea_contenido);
    }else if(strcmp(linea_nombre, "VmStk:") == 0){
        strcpy(info.tam_stack, linea_contenido);
    }else if(strcmp(linea_nombre, "voluntary_ctxt_switches:") == 0){
        strcpy(info.cambio_contexto_v, linea_contenido);
    }else if(strcmp(linea_nombre, "nonvoluntary_ctxt_switches:") == 0){
        strcpy(info.cambio_contexto_nv, linea_contenido);
    }
  }
  fclose(fp);
  return info;
}

void printInfo(infoProceso info){
    printf(" Nombre del proceso: %s \n", info.nombre);
    printf(" Estado: %s \n", info.estado);
    printf(" Tamaño total de la imagen de memoria: %s \n", info.tam_total);
    printf("     Tamaño de la memoria en la región TEXT: %s \n", info.tam_text);
    printf("     Tamaño de la memoria en la región DATA: %s \n", info.tam_data);
    printf("     Tamaño de la memoria en la región STACK: %s \n", info.tam_stack);
    printf(" Número de cambios de contexto voluntarios realizados: %s \n", info.cambio_contexto_v);
    printf(" Número de cambios de contexto no voluntarios realizados: %s \n", info.cambio_contexto_nv);
}

void guardarInfo(char archivo[], char proceso[], infoProceso info){
    FILE *fp;

    fp = fopen(archivo, "a");
    if(fp == NULL){
      printf("Error al tratar de acceder el archivo");
      exit(1);
    }
      
    fprintf(fp, "\n Pid: %s \n", proceso);
    fprintf(fp, " Nombre del proceso: %s \n", info.nombre);
    fprintf(fp, " Estado: %s \n", info.estado);
    fprintf(fp, " Tamaño total de la imagen de memoria: %s \n", info.tam_total);
    fprintf(fp, "     Tamaño de la memoria en la región TEXT: %s \n", info.tam_text);
    fprintf(fp, "     Tamaño de la memoria en la región DATA: %s \n", info.tam_data);
    fprintf(fp, "     Tamaño de la memoria en la región STACK: %s \n", info.tam_stack);
    fprintf(fp, " Número de cambios de contexto voluntarios realizados: %s \n", info.cambio_contexto_v);
    fprintf(fp, " Número de cambios de contexto no voluntarios realizados: %s \n", info.cambio_contexto_nv);

    fclose(fp);
}

void mostrarValidos(){
    printf("La llamada al programa con parámetros válidos es de la siguiente manera: \n");
    printf("1) Con un solo parámetro: ./psinfo pid \n");
    printf("2) Múltiples parámetros con la opción lista (-l): ./psinfo -l pid1 pid2 ... pidn \n");
    printf("3) Múltiples parámetros con la opción reporte (-r): ./psinfo -r pid1 ... pidn \n");
}